import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class App {
    public static void main(String[] args) {

        Cliente cliente = new Cliente(
            "12.345.678/0001-90", 
            "Empresa Exemplo Ltda", 
            "Rua das Flores, 123", 
            "1234-5678", 
            "João da Silva", 
            "Varejo", 
            "Rua das Flores, 456", 
            "Rua das Flores, 789",
            "Rua das Flores, 101",
            "01/01/2022"
        );


        Produto produto1 = new Produto("P001", "Produto A", "Vermelho", "10x10", 1.5, 25.0, 3, "Desenho A");
        Produto produto2 = new Produto("P002", "Produto B", "Azul", "15x15", 2.0, 30.0, 4, "Desenho B");


        MateriaPrima materiaPrima = new MateriaPrima("MP001", "Matéria-prima A", 100, 10.0, "kg");

        MaterialDiverso materialDiverso = new MaterialDiverso("MD001", "Material Diverso A", 50, 5.0, "unidade");

        Maquina maquina = new Maquina("M001", "Máquina A", 2, 10000.0, "unidade", 5, "01/01/2020", "01/01/2025");

        Ferramenta ferramenta = new Ferramenta("F001", "Ferramenta A", 10, 150.0, "unidade", 30);

        MaoDeObra maoDeObra = new MaoDeObra("M001", "Maria Oliveira", "Av. dos Trabalhadores, 456", "9876-5432", "Operadora", 3000.0, "01/01/2020", "Qualificação A");

        List<String> telefonesFornecedor = new ArrayList<>();
        telefonesFornecedor.add("1234-5678");
        Fornecedor fornecedor = new Fornecedor("12.345.678/0001-90", "Fornecedor Exemplo", "Rua do Fornecedor, 123", telefonesFornecedor, "Pedro Almeida");

        EmpresaManutencao empresaManutencao = new EmpresaManutencao("98.765.432/0001-10", "Manutenção Exemplo", "Rua da Manutenção, 123", telefonesFornecedor, "Carlos Mendes");

        Manutencao manutencao = new Manutencao(maquina, empresaManutencao, new Date(), "Troca de óleo e ajuste");

        Encomenda encomenda = new Encomenda("EN001", new Date(), 500.0, 50.0, 450.0, "Cartão", 3, cliente);
        
        ProdutoSolicitado produtoSolicitado1 = new ProdutoSolicitado(produto1, 2, new Date());
        ProdutoSolicitado produtoSolicitado2 = new ProdutoSolicitado(produto2, 1, new Date());
        
        encomenda.adicionarProduto(produtoSolicitado1);
        encomenda.adicionarProduto(produtoSolicitado2);

        System.out.println("Cliente: " + cliente.getRazaoSocial());
        System.out.println("CNPJ: " + cliente.getCnpj());
        
        System.out.println("\nProdutos:");
        System.out.println("1. " + produto1.getNome() + " - Código: " + produto1.getCodigo() + ", Cor: " + produto1.getCor() + ", Preço: R$" + produto1.getPreco());
        System.out.println("2. " + produto2.getNome() + " - Código: " + produto2.getCodigo() + ", Cor: " + produto2.getCor() + ", Preço: R$" + produto2.getPreco());
        
        System.out.println("\nMatéria-prima:");
        System.out.println("Código: " + materiaPrima.getCodigo() + ", Nome: " + materiaPrima.getNome() + ", Preço: R$" + materiaPrima.getPrecoUnitario());
        
        System.out.println("\nMaterial Diverso:");
        System.out.println("Código: " + materialDiverso.getCodigo() + ", Nome: " + materialDiverso.getNome() + ", Preço: R$" + materialDiverso.getPrecoUnitario());
        
        System.out.println("\nMáquina:");
        System.out.println("Código: " + maquina.getCodigo() + ", Nome: " + maquina.getNome() + ", Preço: R$" + maquina.getPrecoUnitario() + ", Tempo de Vida: " + maquina.getTempoVida() + " anos");
        
        System.out.println("\nFerramenta:");
        System.out.println("Código: " + ferramenta.getCodigo() + ", Nome: " + ferramenta.getNome() + ", Preço: R$" + ferramenta.getPrecoUnitario());
        
        System.out.println("\nMão de Obra:");
        System.out.println("Matrícula: " + maoDeObra.getMatricula() + ", Nome: " + maoDeObra.getNome() + ", Salário: R$" + maoDeObra.getSalario());
        
        System.out.println("\nFornecedor:");
        System.out.println("CNPJ: " + fornecedor.getCnpj() + ", Razão Social: " + fornecedor.getRazaoSocial());
        
        System.out.println("\nEmpresa de Manutenção:");
        System.out.println("CNPJ: " + empresaManutencao.getCnpj() + ", Razão Social: " + empresaManutencao.getRazaoSocial());
        
        System.out.println("\nManutenção:");
        System.out.println("Máquina: " + manutencao.getMaquina().getNome() + ", Empresa: " + manutencao.getEmpresa().getRazaoSocial());
        
        System.out.println("\nEncomenda número: " + encomenda.getNumero());
        System.out.println("Valor total: R$" + encomenda.getValorTotal());
        System.out.println("Produtos solicitados:");
        for (ProdutoSolicitado ps : encomenda.getProdutosSolicitados()) {
            System.out.println("- " + ps.getProduto().getNome() + " (Quantidade: " + ps.getQuantidade() + ")");
        }
    }
}

