import java.util.ArrayList;
import java.util.List;
import java.util.Date;

class Cliente {
    private String cnpj;
    private String razaoSocial;
    private String endereco;
    private String telefone;
    private String contato;
    private String ramoAtividade;
    private String enderecoCobranca;
    private String enderecoCorrespondencia;
    private String enderecoEntrega;
    private String dataCadastro;

    public Cliente(String cnpj, String razaoSocial, String endereco, String telefone, String contato, String ramoAtividade, String enderecoCobranca, String enderecoCorrespondencia, String enderecoEntrega, String dataCadastro) {
        this.cnpj = cnpj;
        this.razaoSocial = razaoSocial;
        this.endereco = endereco;
        this.telefone = telefone;
        this.contato = contato;
        this.ramoAtividade = ramoAtividade;
        this.enderecoCobranca = enderecoCobranca;
        this.enderecoCorrespondencia = enderecoCorrespondencia;
        this.enderecoEntrega = enderecoEntrega;
        this.dataCadastro = dataCadastro;
    }

    // ENCAPSULAMENTO
    public String getCnpj() { return cnpj; }
    public void setCnpj(String cnpj) { this.cnpj = cnpj; }

    public String getRazaoSocial() { return razaoSocial; }
    public void setRazaoSocial(String razaoSocial) { this.razaoSocial = razaoSocial; }

    public String getEndereco() { return endereco; }
    public void setEndereco(String endereco) { this.endereco = endereco; }

    public String getTelefone() { return telefone; }
    public void setTelefone(String telefone) { this.telefone = telefone; }

    public String getContato() { return contato; }
    public void setContato(String contato) { this.contato = contato; }

    public String getRamoAtividade() { return ramoAtividade; }
    public void setRamoAtividade(String ramoAtividade) { this.ramoAtividade = ramoAtividade; }

    public String getEnderecoCobranca() { return enderecoCobranca; }
    public void setEnderecoCobranca(String enderecoCobranca) { this.enderecoCobranca = enderecoCobranca; }

    public String getEnderecoCorrespondencia() { return enderecoCorrespondencia; }
    public void setEnderecoCorrespondencia(String enderecoCorrespondencia) { this.enderecoCorrespondencia = enderecoCorrespondencia; }

    public String getEnderecoEntrega() { return enderecoEntrega; }
    public void setEnderecoEntrega(String enderecoEntrega) { this.enderecoEntrega = enderecoEntrega; }

    public String getDataCadastro() { return dataCadastro; }
    public void setDataCadastro(String dataCadastro) { this.dataCadastro = dataCadastro; }
}

class Produto {
    private String codigo;
    private String nome;
    private String cor;
    private String dimensoes;
    private double peso;
    private double preco;
    private int tempoFabricacao;
    private String desenho;

    public Produto(String codigo, String nome, String cor, String dimensoes, double peso, double preco, int tempoFabricacao, String desenho) {
        this.codigo = codigo;
        this.nome = nome;
        this.cor = cor;
        this.dimensoes = dimensoes;
        this.peso = peso;
        this.preco = preco;
        this.tempoFabricacao = tempoFabricacao;
        this.desenho = desenho;
    }

    // ENCAPSULAMENTO
    public String getCodigo() { return codigo; }
    public void setCodigo(String codigo) { this.codigo = codigo; }

    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }

    public String getCor() { return cor; }
    public void setCor(String cor) { this.cor = cor; }

    public String getDimensoes() { return dimensoes; }
    public void setDimensoes(String dimensoes) { this.dimensoes = dimensoes; }

    public double getPeso() { return peso; }
    public void setPeso(double peso) { this.peso = peso; }

    public double getPreco() { return preco; }
    public void setPreco(double preco) { this.preco = preco; }

    public int getTempoFabricacao() { return tempoFabricacao; }
    public void setTempoFabricacao(int tempoFabricacao) { this.tempoFabricacao = tempoFabricacao; }

    public String getDesenho() { return desenho; }
    public void setDesenho(String desenho) { this.desenho = desenho; }
}

abstract class Componente {
    private String codigo;
    private String nome;
    private int quantidadeEstoque;
    private double precoUnitario;
    private String unidadeEstoque;

    public Componente(String codigo, String nome, int quantidadeEstoque, double precoUnitario, String unidadeEstoque) {
        this.codigo = codigo;
        this.nome = nome;
        this.quantidadeEstoque = quantidadeEstoque;
        this.precoUnitario = precoUnitario;
        this.unidadeEstoque = unidadeEstoque;
    }

    // ENCAPSULAMENTO
    public String getCodigo() { return codigo; }
    public void setCodigo(String codigo) { this.codigo = codigo; }
    
    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }

    public int getQuantidadeEstoque() { return quantidadeEstoque; }
    public void setQuantidadeEstoque(int quantidadeEstoque) { this.quantidadeEstoque = quantidadeEstoque; }

    public double getPrecoUnitario() { return precoUnitario; }
    public void setPrecoUnitario(double precoUnitario) { this.precoUnitario = precoUnitario; }

    public String getUnidadeEstoque() { return unidadeEstoque; }
    public void setUnidadeEstoque(String unidadeEstoque) { this.unidadeEstoque = unidadeEstoque; }
}

//Herança
class MateriaPrima extends Componente {
    public MateriaPrima(String codigo, String nome, int quantidadeEstoque, double precoUnitario, String unidadeEstoque) {
        super(codigo, nome, quantidadeEstoque, precoUnitario, unidadeEstoque);
    }
}

//Herança
class MaterialDiverso extends Componente {
    public MaterialDiverso(String codigo, String nome, int quantidadeEstoque, double precoUnitario, String unidadeEstoque) {
        super(codigo, nome, quantidadeEstoque, precoUnitario, unidadeEstoque);
    }
}

//Herança
class Maquina extends Componente {
    private int tempoVida;
    private String dataCompra;
    private String dataFimGarantia;

    public Maquina(String codigo, String nome, int quantidadeEstoque, double precoUnitario, String unidadeEstoque, int tempoVida, String dataCompra, String dataFimGarantia) {
        super(codigo, nome, quantidadeEstoque, precoUnitario, unidadeEstoque);
        this.tempoVida = tempoVida;
        this.dataCompra = dataCompra;
        this.dataFimGarantia = dataFimGarantia;
    }

    // ENCAPSULAMENTO
    public int getTempoVida() { return tempoVida; }
    public void setTempoVida(int tempoVida) { this.tempoVida = tempoVida; }

    public String getDataCompra() { return dataCompra; }
    public void setDataCompra(String dataCompra) { this.dataCompra = dataCompra; }

    public String getDataFimGarantia() { return dataFimGarantia; }
    public void setDataFimGarantia(String dataFimGarantia) { this.dataFimGarantia = dataFimGarantia; }
}

//Herança
class Ferramenta extends Componente {
    private int tempoUsoNecessario; 

    public Ferramenta(String codigo, String nome, int quantidadeEstoque, double precoUnitario, String unidadeEstoque, int tempoUsoNecessario) {
        super(codigo, nome, quantidadeEstoque, precoUnitario, unidadeEstoque);
        this.tempoUsoNecessario = tempoUsoNecessario;
    }

    // ENCAPSULAMENTO
    public int getTempoUsoNecessario() { return tempoUsoNecessario; }
    public void setTempoUsoNecessario(int tempoUsoNecessario) { this.tempoUsoNecessario = tempoUsoNecessario; }
}

class MaoDeObra {
    private String matricula;
    private String nome;
    private String endereco;
    private String telefone;
    private String cargo;
    private double salario;
    private String dataAdmissao;
    private String qualificacoes;

    public MaoDeObra(String matricula, String nome, String endereco, String telefone, String cargo, double salario, String dataAdmissao, String qualificacoes) {
        this.matricula = matricula;
        this.nome = nome;
        this.endereco = endereco;
        this.telefone = telefone;
        this.cargo = cargo;
        this.salario = salario;
        this.dataAdmissao = dataAdmissao;
        this.qualificacoes = qualificacoes;
    }

    // ENCAPSULAMENTO
    public String getMatricula() { return matricula; }
    public void setMatricula(String matricula) { this.matricula = matricula; }

    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }

    public String getEndereco() { return endereco; }
    public void setEndereco(String endereco) { this.endereco = endereco; }

    public String getTelefone() { return telefone; }
    public void setTelefone(String telefone) { this.telefone = telefone; }

    public String getCargo() { return cargo; }
    public void setCargo(String cargo) { this.cargo = cargo; }

    public Double getSalario() { return salario; }
    public void setSalario(Double salario) { this.salario = salario; }

    public String getDataAdimissao() { return dataAdmissao; }
    public void setDataAdimissao(String dataAdmissao) { this.dataAdmissao = dataAdmissao; }

    public String getQualificacoes() { return qualificacoes; }
    public void setQualificacoes(String qualificacoes) { this.qualificacoes = qualificacoes; }

}

class Encomenda {
    private String numero;
    private Date dataInclusao;
    private double valorTotal;
    private double valorDesconto;
    private double valorLiquido;
    private String formaPagamento; // cheque, dinheiro, cartão
    private int quantidadeParcelas;
    private Cliente cliente;
    private List<ProdutoSolicitado> produtosSolicitados;

    public Encomenda(String numero, Date dataInclusao, double valorTotal, double valorDesconto, double valorLiquido, String formaPagamento, int quantidadeParcelas, Cliente cliente) {
        this.numero = numero;
        this.dataInclusao = dataInclusao;
        this.valorTotal = valorTotal;
        this.valorDesconto = valorDesconto;
        this.valorLiquido = valorLiquido;
        this.formaPagamento = formaPagamento;
        this.quantidadeParcelas = quantidadeParcelas;
        this.cliente = cliente;
        this.produtosSolicitados = new ArrayList<>();
    }

     // ENCAPSULAMENTO
    public String getNumero() { return numero; }
    public void setNumero(String numero) { this.numero = numero; }

    public Date getDataInclusao() { return dataInclusao; }
    public void setDataInclusao(Date dataInclusao) { this.dataInclusao = dataInclusao; }

    public double getValorTotal() { return valorTotal; }
    public void setValorTotal(double valorTotal) { this.valorTotal = valorTotal; }

    public double getValorDesconto() { return valorDesconto; }
    public void setValorDesconto(double valorDesconto) { this.valorDesconto = valorDesconto; }

    public double getValorLiquido() { return valorLiquido; }
    public void setValorLiquido(double valorLiquido) { this.valorLiquido = valorLiquido; }

    public String getFormaPagamento() { return formaPagamento; }
    public void setFormaPagamento(String formaPagamento) { this.formaPagamento = formaPagamento; }

    public int getQuantidadeParcelas() { return quantidadeParcelas; }
    public void setQuantidadeParcelas(int quantidadeParcelas) { this.quantidadeParcelas = quantidadeParcelas; }

    public Cliente getCliente() { return cliente; }
    public void setCliente(Cliente cliente) { this.cliente = cliente; }
    
    public List<ProdutoSolicitado> getProdutosSolicitados() { return produtosSolicitados; }
    public void adicionarProduto(ProdutoSolicitado produto) { this.produtosSolicitados.add(produto); }
}

// Classe para representar um Produto solicitado em uma Encomenda
class ProdutoSolicitado {
    private Produto produto;
    private int quantidade;
    private Date dataNecessidade;

    public ProdutoSolicitado(Produto produto, int quantidade, Date dataNecessidade) {
        this.produto = produto;
        this.quantidade = quantidade;
        this.dataNecessidade = dataNecessidade;
    }

     // ENCAPSULAMENTO
    public Produto getProduto() { return produto; }
    public void setProduto(Produto produto) { this.produto = produto; }
    
    public int getQuantidade() { return quantidade; }
    public void setQuantidade(int quantidade) { this.quantidade = quantidade; }
    
    public Date getDataNecessidade() { return dataNecessidade; }
    public void setDataNecessidade(Date dataNecessidade) { this.dataNecessidade = dataNecessidade; }
}

// Classe para representar um Fornecedor
class Fornecedor {
    private String cnpj;
    private String razaoSocial;
    private String endereco;
    private List<String> telefones;
    private String pessoaContato;

    public Fornecedor(String cnpj, String razaoSocial, String endereco, List<String> telefones, String pessoaContato) {
        this.cnpj = cnpj;
        this.razaoSocial = razaoSocial;
        this.endereco = endereco;
        this.telefones = telefones;
        this.pessoaContato = pessoaContato;
    }

     // ENCAPSULAMENTO
    public String getCnpj() { return cnpj; }
    public void setCnpj(String cnpj) { this.cnpj = cnpj; }

    public String getRazaoSocial() { return razaoSocial; }
    public void setRazaoSocial(String razaoSocial) { this.razaoSocial = razaoSocial; }

    public String getEndereco() { return endereco; }
    public void setEndereco(String endereco) { this.endereco = endereco; }

    public List<String> getTelefones() { return telefones; }
    public void setTelefones(List<String> telefones) { this.telefones = telefones; }

    public String getPessoaContato() { return pessoaContato; }
    public void setPessoaContato(String pessoaContato) { this.pessoaContato = pessoaContato; }
}

// Classe para representar uma Empresa de Manutenção
class EmpresaManutencao {
    private String cnpj;
    private String razaoSocial;
    private String endereco;
    private List<String> telefones;
    private String pessoaContato;

    public EmpresaManutencao(String cnpj, String razaoSocial, String endereco, List<String> telefones, String pessoaContato) {
        this.cnpj = cnpj;
        this.razaoSocial = razaoSocial;
        this.endereco = endereco;
        this.telefones = telefones;
        this.pessoaContato = pessoaContato;
    }

     // ENCAPSULAMENTO
    public String getCnpj() { return cnpj; }
    public void setCnpj(String cnpj) { this.cnpj = cnpj; }

    public String getRazaoSocial() { return razaoSocial; }
    public void setRazaoSocial(String razaoSocial) { this.razaoSocial = razaoSocial; }

    public String getEndereco() { return endereco; }
    public void setEndereco(String endereco) { this.endereco = endereco; }

    public List<String> getTelefones() { return telefones; }
    public void setTelefones(List<String> telefones) { this.telefones = telefones; }

    public String getPessoaContato() { return pessoaContato; }
    public void setPessoaContato(String pessoaContato) { this.pessoaContato = pessoaContato; }
}

// Classe para representar a Manutenção de uma Máquina
class Manutencao {
    private Maquina maquina;
    private EmpresaManutencao empresa;
    private Date dataManutencao;
    private String descricaoAcoes;

    public Manutencao(Maquina maquina, EmpresaManutencao empresa, Date dataManutencao, String descricaoAcoes) {
        this.maquina = maquina;
        this.empresa = empresa;
        this.dataManutencao = dataManutencao;
        this.descricaoAcoes = descricaoAcoes;
    }

     // ENCAPSULAMENTO
    public Maquina getMaquina() { return maquina; }
    public void setMaquina(Maquina maquina) { this.maquina = maquina; }

    public EmpresaManutencao getEmpresa() { return empresa; }
    public void setEmpresa(EmpresaManutencao empresa) { this.empresa = empresa; }

    public Date getDataManutencao() { return dataManutencao; }
    public void setDataManutencao(Date dataManutencao) { this.dataManutencao = dataManutencao; }

    public String getDescricaoAcoes() { return descricaoAcoes; }
    public void setDescricaoAcoes(String descricaoAcoes) { this.descricaoAcoes = descricaoAcoes; }
}